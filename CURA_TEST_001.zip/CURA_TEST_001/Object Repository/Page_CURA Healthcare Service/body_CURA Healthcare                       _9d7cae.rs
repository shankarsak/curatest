<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>body_CURA Healthcare                       _9d7cae</name>
   <tag></tag>
   <elementGuidId>9393d646-33b8-4e40-b15f-13b87130d6d9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//body</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>body</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>body</value>
      <webElementGuid>c4cb8f92-adee-473b-8b4d-17ac44696c2f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>



    
        
        
            CURA Healthcare
        
        
            Home
        
                
            History
        
        
            Profile
        
        
            Logout
        
            




    
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    



    
        
            
                Make Appointment
                
            
            
                
                    Facility
                    
                        
                            Tokyo CURA Healthcare Center
                            Hongkong CURA Healthcare Center
                            Seoul CURA Healthcare Center
                        
                    
                
                
                    
                        
                             Apply for hospital readmission
                        
                    
                
                
                    Healthcare Program
                    
                        
                             Medicare
                        
                        
                             Medicaid
                        
                        
                             None
                        
                    
                
                
                    Visit Date (Required)
                    
                        
                            
                            
                                
                            
                        
                    
                
                
                    Comment
                    
                        
                    
                
                
                    
                        Book Appointment
                    
                
            
        
    




    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    










id(&quot;appointment&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-12 text-center&quot;]/h2[1]</value>
      <webElementGuid>c739809c-ea4a-4d87-a94c-4246a0046bdd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]</value>
      <webElementGuid>cb0be93c-05d1-45b2-80fb-e5323c5be0ab</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//body</value>
      <webElementGuid>0b434a21-7f96-48c5-b3d4-75bebdcdd7a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//body[(text() = '



    
        
        
            CURA Healthcare
        
        
            Home
        
                
            History
        
        
            Profile
        
        
            Logout
        
            




    
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    



    
        
            
                Make Appointment
                
            
            
                
                    Facility
                    
                        
                            Tokyo CURA Healthcare Center
                            Hongkong CURA Healthcare Center
                            Seoul CURA Healthcare Center
                        
                    
                
                
                    
                        
                             Apply for hospital readmission
                        
                    
                
                
                    Healthcare Program
                    
                        
                             Medicare
                        
                        
                             Medicaid
                        
                        
                             None
                        
                    
                
                
                    Visit Date (Required)
                    
                        
                            
                            
                                
                            
                        
                    
                
                
                    Comment
                    
                        
                    
                
                
                    
                        Book Appointment
                    
                
            
        
    




    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    










id(&quot;appointment&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-12 text-center&quot;]/h2[1]' or . = '



    
        
        
            CURA Healthcare
        
        
            Home
        
                
            History
        
        
            Profile
        
        
            Logout
        
            




    
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    



    
        
            
                Make Appointment
                
            
            
                
                    Facility
                    
                        
                            Tokyo CURA Healthcare Center
                            Hongkong CURA Healthcare Center
                            Seoul CURA Healthcare Center
                        
                    
                
                
                    
                        
                             Apply for hospital readmission
                        
                    
                
                
                    Healthcare Program
                    
                        
                             Medicare
                        
                        
                             Medicaid
                        
                        
                             None
                        
                    
                
                
                    Visit Date (Required)
                    
                        
                            
                            
                                
                            
                        
                    
                
                
                    Comment
                    
                        
                    
                
                
                    
                        Book Appointment
                    
                
            
        
    




    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    










id(&quot;appointment&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-12 text-center&quot;]/h2[1]')]</value>
      <webElementGuid>0a2f0c41-2864-48ca-8ca6-c514eb36cb46</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//body[(text() = '



    
        
        
            CURA Healthcare
        
        
            Home
        
                
            History
        
        
            Profile
        
        
            Logout
        
            




    
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    



    
        
            
                History
                
                            
        
        
                        
                
                    31/01/2024
                    
                        
                            Facility
                        
                        
                            Tokyo CURA Healthcare Center
                        
                        

                        
                            Apply for hospital readmission
                        
                        
                            No
                        
                        

                        
                            Healthcare Program
                        
                        
                            Medicare
                        
                        

                        
                            Comment
                        
                        
                            
                        
                    
                
            
                    
        
            Go to Homepage
        
    




    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    










id(&quot;history&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-offset-2 col-sm-8&quot;]/div[@class=&quot;panel panel-info&quot;]/div[@class=&quot;panel-heading&quot;]' or . = '



    
        
        
            CURA Healthcare
        
        
            Home
        
                
            History
        
        
            Profile
        
        
            Logout
        
            




    
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    



    
        
            
                History
                
                            
        
        
                        
                
                    31/01/2024
                    
                        
                            Facility
                        
                        
                            Tokyo CURA Healthcare Center
                        
                        

                        
                            Apply for hospital readmission
                        
                        
                            No
                        
                        

                        
                            Healthcare Program
                        
                        
                            Medicare
                        
                        

                        
                            Comment
                        
                        
                            
                        
                    
                
            
                    
        
            Go to Homepage
        
    




    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    










id(&quot;history&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-offset-2 col-sm-8&quot;]/div[@class=&quot;panel panel-info&quot;]/div[@class=&quot;panel-heading&quot;]')]</value>
      <webElementGuid>cb30bcf1-a829-4c54-84af-63b9e1009186</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//body[(text() = '



    
        
        
            CURA Healthcare
        
        
            Home
        
                
            History
        
        
            Profile
        
        
            Logout
        
            




    
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    



    
        
            
                History
                
                                    No appointment.
                    
                            
        
        
                    
        
            Go to Homepage
        
    




    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    










id(&quot;history&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-12 text-center&quot;]/p[1]' or . = '



    
        
        
            CURA Healthcare
        
        
            Home
        
                
            History
        
        
            Profile
        
        
            Logout
        
            




    
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    



    
        
            
                History
                
                                    No appointment.
                    
                            
        
        
                    
        
            Go to Homepage
        
    




    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    










id(&quot;history&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-12 text-center&quot;]/p[1]')]</value>
      <webElementGuid>2b19607d-28d6-49ac-8dc7-01f3d0c59b9f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//body[(text() = '



    
        
        
            CURA Healthcare
        
        
            Home
        
                
            History
        
        
            Profile
        
        
            Logout
        
            




    
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    



    
        
            
                Appointment Confirmation
                Please be informed that your appointment has been booked as following:
                
            
            
                
                    Facility
                
                
                    Hongkong CURA Healthcare Center
                
            
            
                
                    Apply for hospital readmission
                
                
                    No
                
            
            
                
                    Healthcare Program
                
                
                    Medicare
                
            
            
                
                    Visit Date
                
                
                    25/01/2024
                
            
            
                
                    Comment
                
                
                    Book Medicare
                
            
            
                Go to Homepage
            
        
    




    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    










id(&quot;summary&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12 text-center&quot;]/p[@class=&quot;lead&quot;]' or . = '



    
        
        
            CURA Healthcare
        
        
            Home
        
                
            History
        
        
            Profile
        
        
            Logout
        
            




    
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    



    
        
            
                Appointment Confirmation
                Please be informed that your appointment has been booked as following:
                
            
            
                
                    Facility
                
                
                    Hongkong CURA Healthcare Center
                
            
            
                
                    Apply for hospital readmission
                
                
                    No
                
            
            
                
                    Healthcare Program
                
                
                    Medicare
                
            
            
                
                    Visit Date
                
                
                    25/01/2024
                
            
            
                
                    Comment
                
                
                    Book Medicare
                
            
            
                Go to Homepage
            
        
    




    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    










id(&quot;summary&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12 text-center&quot;]/p[@class=&quot;lead&quot;]')]</value>
      <webElementGuid>012c249e-b88e-4eaa-b67f-e61bb9efa8a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//body[(text() = '



    
        
        
            CURA Healthcare
        
        
            Home
        
                
            History
        
        
            Profile
        
        
            Logout
        
            




    
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    



    
        
            
                Appointment Confirmation
                Please be informed that your appointment has been booked as following:
                
            
            
                
                    Facility
                
                
                    Hongkong CURA Healthcare Center
                
            
            
                
                    Apply for hospital readmission
                
                
                    Yes
                
            
            
                
                    Healthcare Program
                
                
                    Medicaid
                
            
            
                
                    Visit Date
                
                
                    30/01/2024
                
            
            
                
                    Comment
                
                
                    
                
            
            
                Go to Homepage
            
        
    




    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    










id(&quot;summary&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12 text-center&quot;]/p[@class=&quot;lead&quot;]' or . = '



    
        
        
            CURA Healthcare
        
        
            Home
        
                
            History
        
        
            Profile
        
        
            Logout
        
            




    
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    



    
        
            
                Appointment Confirmation
                Please be informed that your appointment has been booked as following:
                
            
            
                
                    Facility
                
                
                    Hongkong CURA Healthcare Center
                
            
            
                
                    Apply for hospital readmission
                
                
                    Yes
                
            
            
                
                    Healthcare Program
                
                
                    Medicaid
                
            
            
                
                    Visit Date
                
                
                    30/01/2024
                
            
            
                
                    Comment
                
                
                    
                
            
            
                Go to Homepage
            
        
    




    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    










id(&quot;summary&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12 text-center&quot;]/p[@class=&quot;lead&quot;]')]</value>
      <webElementGuid>4b15792e-86ba-4655-b983-0ccd405babb9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//body[(text() = '



    
        
        
            CURA Healthcare
        
        
            Home
        
                
            History
        
        
            Profile
        
        
            Logout
        
            




    
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    



    
        
            
                Appointment Confirmation
                Please be informed that your appointment has been booked as following:
                
            
            
                
                    Facility
                
                
                    Tokyo CURA Healthcare Center
                
            
            
                
                    Apply for hospital readmission
                
                
                    No
                
            
            
                
                    Healthcare Program
                
                
                    Medicare
                
            
            
                
                    Visit Date
                
                
                    25/01/2024
                
            
            
                
                    Comment
                
                
                    
                
            
            
                Go to Homepage
            
        
    




    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    










id(&quot;summary&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12 text-center&quot;]/h2[1]' or . = '



    
        
        
            CURA Healthcare
        
        
            Home
        
                
            History
        
        
            Profile
        
        
            Logout
        
            




    
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    



    
        
            
                Appointment Confirmation
                Please be informed that your appointment has been booked as following:
                
            
            
                
                    Facility
                
                
                    Tokyo CURA Healthcare Center
                
            
            
                
                    Apply for hospital readmission
                
                
                    No
                
            
            
                
                    Healthcare Program
                
                
                    Medicare
                
            
            
                
                    Visit Date
                
                
                    25/01/2024
                
            
            
                
                    Comment
                
                
                    
                
            
            
                Go to Homepage
            
        
    




    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    










id(&quot;summary&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12 text-center&quot;]/h2[1]')]</value>
      <webElementGuid>3dace965-883c-42aa-9fa2-f10cc09c4f1d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
